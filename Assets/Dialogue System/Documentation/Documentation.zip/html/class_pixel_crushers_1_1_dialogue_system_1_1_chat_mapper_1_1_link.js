var class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_link =
[
    [ "ConversationID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_link.html#a4ba4275bce21a165ecd09bcdcdba5c40", null ],
    [ "DestinationConvoID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_link.html#aa825bdf6772279575fc12b5828bfcf81", null ],
    [ "DestinationDialogID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_link.html#a8ea76d9f2aeedc121992e1ca94120725", null ],
    [ "IsConnector", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_link.html#a066c7d631e3472066ffe338169ddcad2", null ],
    [ "OriginConvoID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_link.html#aa18b769004ce5c0452005bf6db7db6ec", null ],
    [ "OriginDialogID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_link.html#a70a016b915a8e5cd31ba855239b2e5d7", null ]
];