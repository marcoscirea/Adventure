var class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_button_text_data =
[
    [ "data", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_button_text_data.html#a3e64cf84fe39643812e912c4ef9e739a", null ],
    [ "message", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_button_text_data.html#a3bc607a6ef188c33d03799fac3db3865", null ],
    [ "target", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_button_text_data.html#a3698126165b67e99499c017e79b7bb68", null ]
];