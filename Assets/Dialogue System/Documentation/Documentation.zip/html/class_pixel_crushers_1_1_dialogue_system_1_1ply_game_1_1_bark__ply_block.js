var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_bark__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_bark__ply_block.html#a070699cc1622923b47f83b037c16e15d", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_bark__ply_block.html#ab645b6fc3b3b3e8294ab9633303832cc", null ],
    [ "actor", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_bark__ply_block.html#a2e2ebbb61c3494c72f90fb1d81b50ac3", null ],
    [ "conversant", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_bark__ply_block.html#a50044c05c5866336c4faa48001691e74", null ],
    [ "conversation", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_bark__ply_block.html#a27320d09d292603f9dd1c85e991f596a", null ]
];