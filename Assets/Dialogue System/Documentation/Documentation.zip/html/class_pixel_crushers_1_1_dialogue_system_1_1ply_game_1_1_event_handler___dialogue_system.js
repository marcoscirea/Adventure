var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___dialogue_system =
[
    [ "AddEvent", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___dialogue_system.html#abb4a9789d99c75d08d0052d4fb523f8d", null ],
    [ "CheckEvents", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___dialogue_system.html#a687b388243e2e68f0ae4becfb374776a", null ],
    [ "StateChanged", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___dialogue_system.html#a2255d2c41aec273ae51b8429a0c9127f", null ]
];