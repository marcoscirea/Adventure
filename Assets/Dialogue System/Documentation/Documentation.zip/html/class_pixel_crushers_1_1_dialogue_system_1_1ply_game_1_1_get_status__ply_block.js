var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_status__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_status__ply_block.html#a2c35dc82efe3e3dcdc0c8ba9f38df9a7", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_status__ply_block.html#af58e3a0d32202d19fb2a0c52f1d79a4b", null ],
    [ "asset1", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_status__ply_block.html#a46047af26ed072f8616797ae1f4bb24f", null ],
    [ "asset2", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_status__ply_block.html#a86d82833b6ae985fc1098b0010468435", null ]
];